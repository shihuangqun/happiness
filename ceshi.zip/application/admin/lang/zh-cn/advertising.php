<?php

return [
    'Type'     => '显示位置',
    'Type 0'   => '首页轮播图',
    'Type 1'   => '课程底部广告',
    'Type 2'   => '首页限时折扣',
    'Image'    => '图片',
    'Url'      => 'URL',
    'Weigh'    => '排序',
    'Status'   => '状态',
    'Status 1' => '正常',
    'Status 0' => '隐藏'
];
