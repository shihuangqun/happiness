<?php

return [
    'Id'            => 'ID',
    'Course_id'     => '课程ID',
    'Title'         => '标题',
    'Image'         => '封面图',
    'Video_file'    => '视频',
    'Audio_file'    => '音频',
    'Duration'      => '时长',
    'Is_audition'   => '试听章节',
    'Is_audition 1' => '是',
    'Is_audition 0' => '否',
    'Weigh'         => '排序',
    'Status'        => '状态',
    'Status 1'      => '正常',
    'Status 0'      => '隐藏',
    'Createtime'    => '创建时间',
    'Course.title'  => '课程名称'
];
