<?php

return [
    'Nickname'       => '用户昵称',
    'Title'          => '课程名称',
    'Comment_rank'   => '评价等级',
    'Comment_rank 0' => '好评',
    'Comment_rank 1' => '中评',
    'Comment_rank 2' => '差评',
    'Comment'        => '评价内容',
    'Reply'          => '回复内容',
    'Status'         => '状态',
    'Status 0'       => '待审核',
    'Status 1'       => '审核通过',
    'Status 2'       => '审核未通过',
    'Reply_status'   => '回复状态',
    'Reply_status 0' => '未回复',
    'Reply_status 1' => '已回复',
    'Createtime'     => '创建时间'
];
