<?php

return [
    'One'      => '一级比例（%）',
    'Two'      => '二级比例（%）',
    'Three'    => '三级比例（%）',
    'Status'   => '状态',
    'Status 1' => '开启',
    'Status 0' => '禁用'
];
