<?php

return [
    'Id'            => 'ID',
    'Type'          => '课程类型(单选)',
    'Type 0'        => '入门',
    'Type 1'        => '中级',
    'Type 2'        => '高级',
    'Teacher_id'    => '课程讲师',
    'Image'         => '课程封面',
    'Title'         => '课程名称',
    'Category_id'   => '课程分类',
    'Sales'         => '销量',
    'Stock'         => '库存',
    'Price'         => '价格',
    'Gratisrank'    => '免费学习等级(暂时不用)',
    'Studynum'      => '学习人数',
    'Coursecontent' => '课程介绍',
    'Updatestatus'  => '更新状态',
    'Weight'        => '排序',
    'Status'        => '状态',
    'Status 1'      => '上架',
    'Status 0'      => '下架',
    'Teacher.name'  => '讲师名称'
];
