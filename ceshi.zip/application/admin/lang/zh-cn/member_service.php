<?php

return [
    'Title'           => '名称',
    'Price'           => '价格',
    'Give'            => '赠送积分',
    'Member_discount' => '会员折扣',
    'Status'          => '状态',
    'Status 1'        => '显示',
    'Status 0'        => '隐藏',
    'Weigh'           => '排序',
    'Commission'      => '佣金比例'
];
