<?php

return [
    'Name'     => '标题',
    'Image'    => '缩略图',
    'Content'  => '内容',
    'Status'   => '状态',
    'Status 1' => '正常',
    'Status 0' => '隐藏'
];
