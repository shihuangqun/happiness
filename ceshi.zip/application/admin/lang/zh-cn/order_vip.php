<?php

return [
    'Id'                  => 'ID',
    'Order_num'           => '订单编号',
    'Memberservice_id'    => '会员ID',
    'User_id'             => '用户ID',
    'Price'               => '价格',
    'Commission'          => '一级佣金',
    'Recomment'           => '一级推荐人ID',
    'Commission_two'      => '二级佣金',
    'Recommend_two'       => '二级推荐人ID',
    'Commission_three'    => '三级佣金',
    'Recommend_three'     => '三级推荐人ID',
    'Pay_type'            => '支付方式',
    'Pay_type 0'          => '其他',
    'Pay_type 1'          => '微信支付',
    'Order_status'        => '支付状态',
    'Order_status 0'      => '待付款',
    'Order_status 1'      => '已付款',
    'Order_status 2'      => '已取消',
    'Crearetime'          => '下单时间',
    'Paymenttime'         => '付款时间',
    'Memberservice.title' => '名称',
    'User.username'       => '用户名'
];
