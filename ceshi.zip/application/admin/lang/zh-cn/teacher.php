<?php

return [
    'Name'        => '讲师名称',
    'Image'       => '讲师头像',
    'Wechatimage' => '微信二维码',
    'Qq'          => '讲师QQ',
    'Description' => '介绍',
    'Weigh'       => '排序',
    'Status'      => '状态',
    'Status 1'    => '正常',
    'Status 0'    => '隐藏',
    'Createtime'  => '创建时间'
];
