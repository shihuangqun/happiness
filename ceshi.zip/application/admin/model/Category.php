<?php

namespace app\admin\model;

use think\Model;

class Category extends Model
{
    // 表名
    protected $name = 'category';
    
}
